package com.grizzly.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.grizzly.pojo.GrizzlyPojo;

public class ProductDaoImpl implements ProductDao {
	
	public  ArrayList inventoryFetch() throws ApplicationException 
	{
		
		  SessionFactory sf= null;
		  Session session = null;
		  sf=HibernateUtil.getSessionFactory();
		  session=sf.openSession();
		  ArrayList allProducts=new ArrayList();
		  try
		  {
			  List list=session.createQuery("from Product").list();
			  System.out.println(list.size());
			  int required=0;
	    	  for(int i=0;i<list.size();i++)
	    	  {
	    		  Product prod= (Product)list.get(i);
	    		  GrizzlyPojo gPojo= new GrizzlyPojo();
	    		  gPojo.setProductId(prod.getProduct_id());
	    		  System.out.println(prod.getProduct_id());
	    		  gPojo.setProductName(prod.getProduct_name());
	    		  gPojo.setProductBrand(prod.getProduct_brand());
	    		  gPojo.setProductCategory(prod.getProduct_category());
	    		  gPojo.setProductRating(prod.getProduct_rating());
	    		  gPojo.setProductPrice(prod.getProduct_price());
	    		  gPojo.setInventoryBuffer(prod.getInventory().getInventory_buffer());
	    		  gPojo.setInventoryInstock(prod.getInventory().getInventory_instock());
	    		  required=gPojo.getInventoryInstock()-gPojo.getInventoryBuffer();
					
					if(required<0)
					{
						required=-(required);
						gPojo.setInventoryRequired(required);

					}
					else
					{
						gPojo.setInventoryRequired(0);
					}
	    		  allProducts.add(gPojo);
	    	  }
		  }
		  catch(HibernateException e)
		  {
			  throw new ApplicationException(e.getMessage());
		  }
		  finally
		  {
			  session.close();
		  }
		  return allProducts;
	}
	
	public void removeProduct(int id) throws ApplicationException 
	{
		  SessionFactory sf=HibernateUtil.getSessionFactory();
		  Session session = sf.openSession();
		  Transaction transaction=session.beginTransaction();
		   try{
		    	Product prod = (Product) session.get(Product.class, id);
		    	
		        session.delete(prod);
		        
		        transaction.commit();
		 
		      } 
		   catch(HibernateException e)
			  {
				  throw new ApplicationException(e.getMessage());
			  }
		   finally
			  {
				  session.close();
			  }
			  

	}
	
	public  void add(GrizzlyPojo pojo) throws ApplicationException 
	{
		   SessionFactory sf= null;
	  	   Session session = null;
	  	 
	       sf=HibernateUtil.getSessionFactory();
	  	   session = sf.openSession();
	  	  
	  	   Transaction transaction=session.beginTransaction();
	  		
	       try
	       {
	       Product product = new Product();
	       product.setProduct_id(pojo.getProductId());
	       product.setProduct_name(pojo.getProductName());
	       product.setProduct_brand(pojo.getProductBrand());
	       product.setProduct_category(pojo.getProductCategory());
	       product.setProduct_rating(pojo.getProductRating());
	       product.setProduct_price(pojo.getProductPrice());
	       session.save(product);
	       session.getTransaction().commit();
	       session.close();
	    
	       sf=HibernateUtil.getSessionFactory();
		   session = sf.openSession();
		  
		   transaction=session.beginTransaction();
		   
		   Inventory inventory = new Inventory();
		 
		   inventory.setProduct_id(pojo.getProductId());
	       inventory.setInventory_buffer(pojo.getInventoryBuffer());
	       inventory.setInventory_instock(pojo.getInventoryBuffer());
	    
	       session.save(inventory);
	       session.getTransaction().commit();
	       }
	       catch(Exception e)
	       {
	    	 throw new ApplicationException(e.getMessage());
	       }
		  finally
		  {
		  session.close();
		  }

	 }

	
	public  void update(GrizzlyPojo pojo) throws ApplicationException 
	{
	       
	       
	      SessionFactory sf= null;
	 	  Session session = null;
	      sf=HibernateUtil.getSessionFactory();
		  session = sf.openSession();
		  
		  Transaction transaction=session.beginTransaction();
			
	      try 
	      {
	      Product product=(Product)session.get(Product.class,pojo.getProductId());
	      product.getInventory().setInventory_buffer(pojo.getInventoryBuffer());
	      product.getInventory().setInventory_instock(pojo.getInventoryInstock());

	 	  session.update(product);
	      session.getTransaction().commit();
	    
	      }
	      catch(HibernateException e)
		  {
		  throw new ApplicationException(e.getMessage());
		  }
		  finally
		  {
	      session.close();
		  }
      }




}
