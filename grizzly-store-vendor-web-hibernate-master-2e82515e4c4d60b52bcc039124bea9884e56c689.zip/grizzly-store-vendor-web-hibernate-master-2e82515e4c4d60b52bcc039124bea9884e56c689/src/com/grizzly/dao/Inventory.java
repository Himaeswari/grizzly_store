package com.grizzly.dao;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="inventory")
public class Inventory {
	
	@Id
	
	@Column(name="product_id")
	private int product_id;
	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="product_id")
	private Product products;
	
	@Column(name="inventory_buffer")
	private int inventory_buffer;

	@Column(name="inventory_instock")
	private int inventory_instock;
	
	

	
		
	
	public Inventory()
	{
		
	}
	
	public Inventory(int product_id,int inventory_buffer,int inventory_instock)
	{
		this.product_id=product_id;
		this.inventory_buffer=inventory_buffer;
		this.inventory_instock=inventory_instock;
	
		
	}

	

	public int getInventory_buffer() {
		return inventory_buffer;
	}

	public void setInventory_buffer(int inventory_buffer) {
		this.inventory_buffer = inventory_buffer;
	}

	public int getInventory_instock() {
		return inventory_instock;
	}

	public void setInventory_instock(int inventory_instock) {
		this.inventory_instock = inventory_instock;
	}

	public Product getProducts() {
		return products;
	}

	public void setProducts(Product products) {
		this.products = products;
	}

	
}
