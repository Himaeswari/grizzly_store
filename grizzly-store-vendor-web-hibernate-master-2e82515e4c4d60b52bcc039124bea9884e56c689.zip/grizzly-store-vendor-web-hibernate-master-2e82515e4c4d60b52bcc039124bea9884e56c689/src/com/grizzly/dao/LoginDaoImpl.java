package com.grizzly.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.grizzly.pojo.LoginPojo;

public class LoginDaoImpl implements LoginDao  
{
	public LoginPojo checkUser(LoginPojo pojo) throws ApplicationException 
	{
	      SessionFactory sf= null;
		  Session session = null;
		  sf=HibernateUtil.getSessionFactory();
		  session=sf.openSession();
	      try
		  {
		         Login login = session.get(Login.class,pojo.getUserName());
				
			     
				  if(login.getUserName()!=null && login.getUserName()!="")
				  {
					  pojo.setUserName(login.getUserName());
					  pojo.setPassword(login.getPassword());
					  pojo.setRole(login.getRole());
					  pojo.setAttempt(login.getAttempts());
				  }
		  }
		  catch(HibernateException e)
		  {
			 throw new ApplicationException(e.getMessage());
		  }
		  finally
		  {
			  session.close();
		  }
				  
		  return pojo;
     }
	
	public  void  loginLock(LoginPojo lPojo) throws ApplicationException 
	{
		  SessionFactory sf= null;
		  Session session = null;
		  String count="inactive";
	      sf=HibernateUtil.getSessionFactory();
		  session = sf.openSession();
		  
		  Transaction transaction=session.beginTransaction();
			
	      try
	      {
		    
		   Login i= new Login(lPojo.getUserName(),lPojo.getPassword(),lPojo.getRole(),count);
		    
		   session.update(i);
	       session.getTransaction().commit();
	      }
	      catch(HibernateException e)
	      {
	    	  throw new ApplicationException(e.getMessage());
	      }
	      finally
	      {
	       session.close();
	      }
		  
		  
		  
	}

}
