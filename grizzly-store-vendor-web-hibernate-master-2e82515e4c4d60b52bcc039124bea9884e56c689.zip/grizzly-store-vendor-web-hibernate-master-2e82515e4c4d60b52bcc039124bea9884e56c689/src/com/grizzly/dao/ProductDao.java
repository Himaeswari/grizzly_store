package com.grizzly.dao;

import java.util.ArrayList;

import com.grizzly.pojo.GrizzlyPojo;

public interface ProductDao {
	ArrayList inventoryFetch() throws ApplicationException;
	void removeProduct(int id) throws ApplicationException;
	void add(GrizzlyPojo gPojo) throws ApplicationException;
	void update(GrizzlyPojo gPojo) throws ApplicationException;
	

}
