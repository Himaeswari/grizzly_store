package com.grizzly.dao;
import com.grizzly.pojo.LoginPojo;
public interface LoginDao {
	
	void  loginLock(LoginPojo lPojo) throws ApplicationException;
	LoginPojo checkUser(LoginPojo lPojo) throws ApplicationException;

}
