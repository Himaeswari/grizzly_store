package com.grizzly.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.grizzly.dao.ApplicationException;
import com.grizzly.service.ProductService;
import com.grizzly.service.ProductServiceImpl;





@WebServlet("/GrizzlyServlet")
public class GrizzlyServlet extends HttpServlet {

	public static Logger logger = Logger.getLogger("Grizzly-store-hibernate");
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("Logout") != null)
		{
			
			HttpSession session = request.getSession(false);
			session.invalidate();
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("Login.jsp");
			dispatcher.forward(request, response);
					
		}
		else if(request.getParameter("AddProducts")!=null) {
			
		    
			RequestDispatcher dispatcher = request.getRequestDispatcher("AddServlet");
			dispatcher.forward(request, response);
		}
		else if(request.getParameter("Product")!=null)
		{
			ProductService product= new ProductServiceImpl();
			 ArrayList allProduct;
			try {
				allProduct = product.inventoryFetch();
				request.setAttribute("allProduct", allProduct);
				 RequestDispatcher dispatcher= request.getRequestDispatcher("FetchVendorProduct.jsp");
				 dispatcher.forward(request, response);
			} catch (ApplicationException e) {
				logger.error(e);
			}
             
		}
		else if(request.getParameter("Inventory")!=null)
		{
			 ProductService product2= new ProductServiceImpl();
			 ArrayList allProduct;
			try {
				allProduct = product2.inventoryFetch();
				request.setAttribute("allProduct", allProduct);
				 RequestDispatcher dispatcher= request.getRequestDispatcher("InventoryFetch.jsp");
				 dispatcher.forward(request, response);
			} catch (ApplicationException e) {
				logger.error(e);
			}
             
		}
		else if(request.getParameter("Update")!=null)
	    {
	         int flag=1;
	      
	         RequestDispatcher dispatcher= request.getRequestDispatcher("UpdateServlet");
			 dispatcher.forward(request, response);
	      
	    }
        else if(request.getParameter("sId")!=null)
		{
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("DeleteServlet");
			dispatcher.forward(request, response);
		}
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    if(request.getParameter("signin") != null)
	    {
		    
		 RequestDispatcher requestDispatcher1=request.getRequestDispatcher("LoginServlet");
        requestDispatcher1.forward(request, response);
		    
		
        }
    }
} 
 
               

			
