package com.grizzly.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.grizzly.dao.ApplicationException;
import com.grizzly.pojo.LoginPojo;
import com.grizzly.service.LoginService;
import com.grizzly.service.LoginServiceImpl;
import com.grizzly.service.ProductService;
import com.grizzly.service.ProductServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	public static Logger logger = Logger.getLogger("Grizzly-store-hibernate");    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
	    String password = request.getParameter("password");
	    
	    LoginPojo pojo = new LoginPojo();
		
		pojo.setUserName(username);
		pojo.setPassword(password);
		System.out.println(pojo.getUserName());
		
		LoginService login = new LoginServiceImpl();
		
		try {
			pojo =login.checkUser(pojo);
		} catch (ApplicationException e) {
			logger.error(e);
		}
		
	    if(pojo.getAttempt()==null)
        {
             RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
             request.setAttribute("error", "Invalid User and Password! Please try again!");
             rd.forward(request, response); 
        }
        else if(pojo.getAttempt().equals("active"))
        { 
        	if(password.equals(pojo.getPassword()))
             {
                 
        	            HttpSession session=request.getSession();
                        session.setAttribute("username", username);
                        
                        session.removeAttribute("attempt");
                        session=request.getSession();
                        String user=(String) session.getAttribute("username");
                        
                        if(pojo.getRole().equals("Vendor") ) 
                        {
                        	ProductService product5= new ProductServiceImpl();
                             ArrayList allProduct;
							try {
								allProduct = product5.inventoryFetch();
								session=request.getSession();
	                            request.setAttribute("allProduct", allProduct);
	                            
	                            RequestDispatcher requestDispatcher=request.getRequestDispatcher("FetchVendorProduct.jsp");
	                            requestDispatcher.forward(request, response);
	                            
							} catch (ApplicationException e) {
								logger.error(e);
							}
                             
                        }
                        else
                        {
                        	ProductService product6= new ProductServiceImpl();
                        	ArrayList allProducts;
							try {
								allProducts = product6.inventoryFetch();
								request.setAttribute("allProducts", allProducts);
								
	                            RequestDispatcher requestDispatcher=request.getRequestDispatcher("FetchProduct.jsp");
	                            requestDispatcher.forward(request, response);
	                            
							} catch (ApplicationException e) {
								logger.error(e);
							}
                        	
                        }
               }
               else
               {
                         HttpSession session=request.getSession();
                         String user=(String) session.getAttribute("user");
                         if(request.getParameter("username").equals(user))
                         {
                                int attempt=(Integer)session.getAttribute("attempt");
                                if(attempt==0)
                                { 
                                	session.setAttribute("username", username);
                                    session.setAttribute("attempt", 1);
                                    
                                    RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                                    request.setAttribute("error", "Invalid Password! Please try again 0!");
                                    rd.forward(request, response); 
                                    
                                }
                               
                                 else if(attempt==2)
                                 {
                                      session.invalidate();
                                      try {
										login.loginLock(pojo);
									} catch (ApplicationException e) {
										logger.error(e);
									}
                                      
                                      RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                                      request.setAttribute("error", "You have attempted thrice with wrong password!!. Account is locked!!");
                                      rd.forward(request, response); 
                                      
                                  }
                                  else
                                  {
                                       session.setAttribute("attempt", ++attempt);
                                       RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                                       
                                       request.setAttribute("error", "Invalid Password! Please try again 1!");
                                       rd.forward(request, response); 
                                       
                                  }
                        }
                        
                  
                         else
                         {
                        session.setAttribute("user", username);
                        session.setAttribute("attempt", 1);
                        
                        RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                        request.setAttribute("error", "Invalid Password! Please try again first!");
                        rd.forward(request, response); 
                        
                         }
                 
                }
           }
           else
           {
                 RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                 request.setAttribute("error", "Account is locked!!");
                 rd.forward(request, response); 
            }
           
    }

}


