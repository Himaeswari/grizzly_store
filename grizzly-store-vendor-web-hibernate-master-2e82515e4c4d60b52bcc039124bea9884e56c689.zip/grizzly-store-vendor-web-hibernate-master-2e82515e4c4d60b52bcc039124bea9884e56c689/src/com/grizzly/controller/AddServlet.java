package com.grizzly.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.grizzly.dao.ApplicationException;
import com.grizzly.pojo.GrizzlyPojo;
import com.grizzly.service.ProductService;
import com.grizzly.service.ProductServiceImpl;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	public static Logger logger = Logger.getLogger("Grizzly-store-hibernate");
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String productsId = request.getParameter("productid");
		int productId=Integer.parseInt(productsId);
		String productName=request.getParameter("productname");
		String productBrand=request.getParameter("productbrand");
		String productCategory=request.getParameter("productcategory");
		String productRatings=request.getParameter("productrating");
		String productPricee=request.getParameter("productprice");
		
		GrizzlyPojo pojo= new GrizzlyPojo();
		
		pojo.setProductId(productId);
		pojo.setProductName(productName);
		pojo.setProductBrand(productBrand);
		pojo.setProductCategory(productCategory);
		pojo.setProductRating(productRatings);
		pojo.setProductPrice(productPricee);
		ProductService product1= new ProductServiceImpl();
		
		try
		{
			product1.add(pojo);
			ArrayList allProducts=product1.inventoryFetch();
				
			request.setAttribute("allProducts", allProducts);
			
			RequestDispatcher rd=request.getRequestDispatcher("FetchProduct.jsp");
			rd.forward(request, response);
		} 
		catch (ApplicationException e) {
			logger.error(e);
		}
		
       
	}

}
