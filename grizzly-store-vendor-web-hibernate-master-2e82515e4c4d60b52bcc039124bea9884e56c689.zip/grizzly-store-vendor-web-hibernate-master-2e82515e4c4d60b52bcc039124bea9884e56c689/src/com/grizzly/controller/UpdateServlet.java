package com.grizzly.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.grizzly.dao.ApplicationException;
import com.grizzly.pojo.GrizzlyPojo;
import com.grizzly.service.ProductService;
import com.grizzly.service.ProductServiceImpl;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	public static Logger logger = Logger.getLogger("Grizzly-store-hibernate");
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 int  stock=Integer.parseInt(request.getParameter("stock"));
         int  buffer=Integer.parseInt(request.getParameter("buffer"));
         String mid=request.getParameter("user");
         int id=Integer.parseInt(mid);
       
         GrizzlyPojo pojo=new GrizzlyPojo();
         pojo.setInventoryInstock(stock);
         pojo.setInventoryBuffer(buffer);
         pojo.setProductId(id);
         ProductService product7= new ProductServiceImpl();
      
          try {
			product7.update(pojo);
			 ProductService product3= new ProductServiceImpl();
             ArrayList allProduct =product3.inventoryFetch();
            request.setAttribute("allProduct",allProduct);
            RequestDispatcher rd=request.getRequestDispatcher("InventoryFetch.jsp");
            rd.forward(request, response);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			logger.error(e);
		}
        
         
         
	}

}
