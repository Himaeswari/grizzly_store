package com.grizzly.service;

import com.grizzly.dao.ApplicationException;
import com.grizzly.dao.LoginDao;
import com.grizzly.dao.LoginDaoImpl;
import com.grizzly.pojo.LoginPojo;

public class LoginServiceImpl implements LoginService {

	LoginDao login= new LoginDaoImpl();
	@Override
	
	public void loginLock(LoginPojo lPojo) throws ApplicationException {
		// TODO Auto-generated method stub
		
		login.loginLock(lPojo);

	}

	@Override
	public LoginPojo checkUser(LoginPojo lPojo) throws ApplicationException {
		// TODO Auto-generated method stub
		LoginPojo pojo=login.checkUser(lPojo);
		return pojo;
	}

	

}
