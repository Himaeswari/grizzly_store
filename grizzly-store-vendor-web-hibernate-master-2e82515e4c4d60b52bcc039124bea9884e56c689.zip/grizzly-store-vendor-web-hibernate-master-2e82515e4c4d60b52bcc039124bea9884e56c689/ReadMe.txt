Account will be locked after 3 wrong passwords
Role check
      Admin 
         Add Product
         Remove Product
         Logout
       Vendor
         Update 
         Fetch Product
         Logout
Service layer
Dao Layer 
Replaced JDBC code in Dao layer with Hibernate
UserDefined Exception
Log4j has been implemented to log the Exception
